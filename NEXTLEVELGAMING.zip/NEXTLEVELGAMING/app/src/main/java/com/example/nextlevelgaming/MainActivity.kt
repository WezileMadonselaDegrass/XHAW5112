package com.example.nextlevelgaming

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBarItem
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

data class GamingPackage(
    val id: Int,
    val name: String,
    val price: Double,
    val duration: String,
    val players: String,
    val tag: String,
    val badge: String? = null,
    val categories: List<String>,
    val inclusions: List<String>
)package com.example.nextlevelgaming

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.example.nextlevelgaming.ui.theme.*
import com.example.nextlevelgaming.viewmodels.ArenaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ArenaViewModel = viewModel()
            val navController = androidx.navigation.compose.rememberNavController()

            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme(
                primary = NeonCyan,
                background = DarkBg,
                surface = CardBg
            )) {
                androidx.compose.material3.Scaffold(
                    bottomBar = {
                        androidx.compose.material3.NavigationBar(containerColor = CardBg) {
                            val navBackStackEntry by navController.currentBackStackEntryAsState()
                            val currentRoute = navBackStackEntry?.destination?.route

                            listOf("Home", "Packages", "Calculator", "About", "Contact").forEach { screen ->
                                NavigationBarItem(
                                    selected = currentRoute == screen.lowercase(),
                                    onClick = { navController.navigate(screen.lowercase()) },
                                    icon = { androidx.compose.material3.Icon(Icons.Default.Games, null) },
                                    label = { androidx.compose.material3.Text(screen) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    androidx.navigation.NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.padding(innerPadding).background(DarkBg)
                    ) {
                        composable("home") { /* Build Home UI here */ }
                        composable("packages") { /* Build Packages UI here */ }
                        composable("calculator") { /* Build Calculator UI here */ }
                        // Add other screens...
                    }
                }
            }
        }
    }
}