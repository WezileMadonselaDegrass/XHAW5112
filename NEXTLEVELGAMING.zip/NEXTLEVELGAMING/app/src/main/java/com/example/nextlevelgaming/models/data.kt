package com.example.nextlevelgaming.models

class data {package com.example.nextlevelgaming.data

    import com.example.nextlevelgaming.models.GamingPackage

    object MockData {
        val packages = listOf(
            GamingPackage(1, "Casual Gaming Session", 35.0, "2 hours", "1–4", "Jump in and play.", "Best value", listOf("Individual", "Family"), listOf("2 hours high-spec station", "Full library access", "Headset hire")),
            GamingPackage(2, "Competitive Training Pack", 65.0, "3 hours", "1–10", "Level up your skills.", null, listOf("Esports", "Club"), listOf("3 hours practice", "Coach-led drills", "Low-latency stations")),
            GamingPackage(3, "Birthday Party Package", 85.0, "3 hours", "6–20", "Make it legendary.", "Popular", listOf("Birthday", "Family"), listOf("Party zone", "Dedicated host", "Mini tournament")),
            GamingPackage(4, "Family Play Session", 40.0, "2 hours", "2–6", "Everyone plays.", null, listOf("Family", "Individual"), listOf("Family lounge", "Age-friendly games", "Co-op stations")),
            GamingPackage(5, "School Group Session", 45.0, "3 hours", "10–40", "Learn, play, connect.", null, listOf("School"), listOf("Teamwork games", "Esports talk", "Supervision included")),
            GamingPackage(6, "Corporate Team Challenge", 95.0, "3 hours", "8–40", "Beat the boardroom.", null, listOf("Corporate"), listOf("Private arena hire", "Live commentator", "Team-building formats"))
        )
    }
}