package com.example.nextlevelgaming.ui.theme

class color {package com.example.nextlevelgaming.ui.theme
    import androidx.compose.ui.graphics.Color

    val DarkBg = Color(0xFF06070C)
    val CardBg = Color(0xFF121420)
    val NeonCyan = Color(0xFF00E5FF)
    val NeonPurple = Color(0xFF7C4DFF)
    val NeonPink = Color(0xFFFF2DAA)
}